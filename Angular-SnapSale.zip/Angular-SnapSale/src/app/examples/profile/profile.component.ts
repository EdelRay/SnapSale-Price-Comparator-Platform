import { Component, OnInit } from "@angular/core";
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";
import { MlService } from "app/ml.service"; // Import your MlService

@Component({
  selector: "app-profile",
  templateUrl: "./profile.component.html",
  styleUrls: ["./profile.component.scss"],
})
export class ProfileComponent implements OnInit {
  userType: string = "";
  safeUrlDashboard!: SafeResourceUrl;
  safeUrlReservation!: SafeResourceUrl;
  formData = {
    Taille: "",
    Produit: "",
    categorieProduit: "",
    Prix_Unitaire: null,
    Quantité_Achetée: null,
    Magasin: "",
    Marque: "",
  };
  showRecommendForm = false;
  clientId: number | null = null;
  recommendations: any[] = [];
  recommendationError: string = "";

  // For prediction form
  marque = ""; // Input model
  response: any; // API response
  showPredictForm = false; // Control form visibility

  constructor(private sanitizer: DomSanitizer, private mlService: MlService) {}

  readonly baseEmbedUrl =
    "https://app.powerbi.com/reportEmbed?reportId=87546c29-f3ff-4303-902e-6980238ec628";
  readonly ctid = "604f1a96-cbe8-43f8-abbf-f8eaf5d85730";

  ngOnInit(): void {
    this.userType = localStorage.getItem("userType") || "customer";
    const userType = localStorage.getItem("userType") as
      | "business"
      | "customer"
      | null;
    const type =
      userType === "business" || userType === "customer"
        ? userType
        : "customer";

    // Dashboard page
    const pageDashboard =
      type === "customer"
        ? "ReportSection171cc0784608eb18ce98"
        : "10e998dfcf8406bd68d4";

    // Reservation page
    const pageReservation =
      type === "customer" ? "bb125793fd5b0737ed2b" : "26eb349a45e991c0e418";

    this.safeUrlDashboard = this.buildUrl(pageDashboard);
    this.safeUrlReservation = this.buildUrl(pageReservation);
  }

  buildUrl(pageName: string): SafeResourceUrl {
    const fullUrl = `${this.baseEmbedUrl}&pageName=${pageName}&autoAuth=true&ctid=${this.ctid}`;
    return this.sanitizer.bypassSecurityTrustResourceUrl(fullUrl);
  }

  // Toggle the form's visibility
  togglePredict() {
    this.showPredictForm = !this.showPredictForm;
  }
  toggleRecommend() {
    this.showRecommendForm = !this.showRecommendForm;
  }
  submit(): void {
    this.mlService.predict(this.formData).subscribe({
      next: (res) => (this.response = res),
      error: (err) => (this.response = err.error),
    });
  }
  submitRecommendation() {
    this.recommendationError = "";
    this.recommendations = [];

    if (this.clientId === null || this.clientId === undefined) {
      this.recommendationError = "Client ID is required.";
      return;
    }

    this.mlService.recommend({ client_id: this.clientId }).subscribe({
      next: (response) => {
        this.recommendations = response;
      },
      error: (error) => {
        this.recommendationError = error.error?.error || "An error occurred";
      },
    });
  }
}
