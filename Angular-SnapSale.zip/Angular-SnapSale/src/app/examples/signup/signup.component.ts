import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-signup",
  templateUrl: "./signup.component.html",
  styleUrls: ["./signup.component.scss"],
})
export class SignupComponent implements OnInit {
  selectedAccountType: string = "customer"; // default selection

  test: Date = new Date();
  focus;
  focus1;
  constructor(private router: Router) {}

  ngOnInit() {}

  login(): void {
    localStorage.setItem("userType", this.selectedAccountType);
    console.log("User type enregistré :", this.selectedAccountType);
    this.router.navigate(["/user-profile"]);
  }
}
