import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MlService {
  private baseUrl = 'http://127.0.0.1:5000';

  constructor(private http: HttpClient) {}

  // First model: RECOMMEND
  recommend(data: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/recommend`, data);
  }

  // Second model: PREDICT
  predict(data: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/predict`, data);
  }
}
